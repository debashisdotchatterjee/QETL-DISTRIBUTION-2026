QETL NUMERICAL AUDIT SUMMARY
==================================
Runtime: 3.31 seconds
Maximum |integral f - 1|: 2.220e-16
Maximum absolute error in -S'=f: 8.344e-12
Maximum relative error in MGF derivative identity: 4.920e-16
Maximum relative error in J recursion: 2.363e-12
Minimum Fisher-information eigenvalue: 2.527e-03
All Fisher matrices positive definite: True
Maximum rejection-sample KS distance: 5.552e-03
